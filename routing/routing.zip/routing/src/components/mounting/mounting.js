import React from 'react';

export default class MountingPhase extends React.Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (
            <div>
                <div>
                    <h1>
                        MOUNTING PHASE
                    </h1>
                    <h3>
                        This is Mounting Phase Here You Can Check With Mounting Of Data
                    </h3>
                </div>
            </div>
        )
    }
}