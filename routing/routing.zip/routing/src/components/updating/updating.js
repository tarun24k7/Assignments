import React from 'react';

export default class MountingPhase extends React.Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (
            <div>
                <div>
                    <h1>
                        UPDATING PHASE
                    </h1>
                    <h3>
                        This is Updating Phase Here You Can Check With Updating Of Data
                    </h3>
                </div>
            </div>
        )
    }
}